<style>
    #map {
        height: 400px;
        width: 100%;
    }
</style>
<?php

	get_header();

	$url_link = "property.xml";
	$url_data = simplexml_load_file($url_link);
	$xml_id = $_GET["id"];

	/* Find and get the node from the property ID */
	$path = '//properties/property/propertyID[text()="'.$xml_id.'"]';
    $found = $url_data->xpath( $path );

    /* If the property ID is not found then false and show error page */
    if( ! count( $found ) )
    {
    	wp_redirect('/404');
    }  else {
    	$node = $found[0]->xpath('parent::*')[0];
    	$this_property = $node;
    }

	$address1 = $this_property->addressName;
	$address2 = $this_property->addressStreet;
	$address3 = $this_property->address3;
	$address4 = $this_property->addressPostcode;
	$address5 = $this_property->country;
	$property_image = $this_property->images->image[0];
	$property_name = $address1 . ", " . $address2 . ", " . $address3;
	$price = $this_property->price;
	$price_int = (int)$price;
	$price_2 = number_format($price_int);


	$paragraph_1 = $this_property->mainSummary;
	$paragraph_2 = $this_property->fullDescription;
?>
<div class="push_top">
	<div class="et_pb_row et_pb_gutters3 custom_width et_pb_equal_columns">
		<div class="et_pb_column et_pb_column_2_3">

			<div class="full_img">
				<div class="slick-images">
				<?php 
					$full_count = 1;
					foreach ($this_property->images->image as $image) {
					?>
						<div data-slide="<?php echo $full_count; ?>" class="big-image">
							<img src="<?php echo $image; ?>">
						</div>
					<?php
					$full_count++;
					}
				 ?>
				</div>
				<!-- <img src="http://via.placeholder.com/700x400"> -->
			</div>
		</div>
		<div class="et_pb_column et_pb_column_1_3">
			<div class="thumbnails">
				<div class="et_pb_row">
					<?php 
					$preview_count = 1;
					foreach ($this_property->images->image as $image) {
					?>
						<div class="et_pb_column et_pb_column_1_2">
							<div class="thumb_1">
								<a data-slide="<?php echo $preview_count; ?>">
									<div class="image-relative" style="background-image: url(<?php echo $image; ?>)"></div>
								</a>
							</div>
						</div>
					<?php 
					$preview_count++;
					} 
					?>
				</div>
			</div>
		</div>
	</div>
	<div class="et_pb_row et_pb_gutters3 custom_width tab_container">
		<div class="et_pb_column et_pb_column_2_3">

			<div class="tabs tab_description tab_active">
				<h2><?php echo $property_name; ?></h2>
				<h3>£ <?php echo $price_2; ?></h3>
				<p><?php echo $paragraph_1; ?></p>

				<h3>Viewing</h3>
				<p><?php echo $paragraph_2; ?></p>
				
				<h3>Energy Performance Certificate</h3>
				<p>Click Here to view the Energy Efficiency Rating and Environmental Impact Rating for this property</p>
				

				<h3>Disclaimer</h3>
				<p>Company Name endeavour to maintain accurate depictions of properties in Virtual Tours, Floor Plans and descriptions, however, these are intended only as a guide and purchasers must satisfy themselves by personal inspection.</p>
			</div>
			<div class="tabs tab_floorplan">
				<img src="http://via.placeholder.com/700x400?text=FloorPlan">
			</div>
			<div class="tabs tab_map">

                <? //print_r($this_property); ?>
                <div id="map"></div>

				
			</div>
			<div class="tabs tab_map_street">
				<img src="http://via.placeholder.com/700x400?text=StreetView Map">
				
			</div>
			<div class="tabs tab_contact">
				<?php echo do_shortcode('[contact-form-7 id="1138" title="Arrange A Viewing"]'); ?>
			</div>
		</div>
		<div class="et_pb_column et_pb_column_1_3">
			<div class="button-container btn_right round-effect blue-btn">
				<a data-tab="tab_description" class="button-cta button-effect btn_tab">Description</a>
			</div>
			<div class="button-container btn_right round-effect pink-btn">
				<a data-tab="tab_contact" class="button-cta button-effect btn_tab">Arrange A Viewing</a>
			</div>
			<div class="button-container btn_right round-effect blue-btn">
				<a data-tab="tab_map" class="button-cta button-effect btn_tab">Map</a>
			</div>
			<div class="button-container btn_right round-effect pink-btn">
				<a data-tab="tab_map_street" class="button-cta button-effect btn_tab">Street View</a>
			</div>
			<div class="button-container btn_right round-effect blue-btn">
				<a data-tab="tab_floorplan" class="button-cta button-effect btn_tab">Floor Plan</a>
			</div>
			<div onclick="window.history.back()" class="button-container btn_right round-effect pink-btn">
				<a class="button-cta button-effect">Go Back</a>
			</div>
			<div onclick="window.history.back()" class="button-container btn_right round-effect blue-btn">
				<a href="../wp-content/themes/barrows-theme/includes/search.php?show_search=true" class="button-cta button-effect">New Search</a>
			</div>
<!-- 			<a class="btn pink" >Go Back</a>
			<a class="btn blue" >New Search</a> -->
		</div>
	</div>
</div>
<script>
    function initMap() {
        var uluru = {lat: -25.363, lng: 131.044};
        var map = new google.maps.Map(document.getElementById('map'), {
            zoom: 4,
            center: uluru
        });
        var marker = new google.maps.Marker({
            position: uluru,
            map: map
        });
    }
</script>
<?php get_footer(); ?>
