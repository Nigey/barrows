window.initMap = function() {
    map = new google.maps.Map(document.getElementById("map"), {
        center: {
            lat: 54.952386,
            lng: -2.878418
        },
        disableDefaultUI: !0,
        styles: [{"featureType":"all","elementType":"labels.text.fill","stylers":[{"color":"#ffffff"}]},{"featureType":"all","elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#3e606f"},{"weight":2},{"gamma":0.84}]},{"featureType":"all","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"administrative","elementType":"geometry","stylers":[{"weight":0.6},{"color":"#1a3541"}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#2c5a71"}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#406d80"}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"color":"#2c5a71"}]},{"featureType":"road","elementType":"geometry","stylers":[{"color":"#29768a"},{"lightness":-37}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#406d80"}]},{"featureType":"water","elementType":"geometry","stylers":[{"color":"#193341"}]}],
        zoom: 6
    });
        new google.maps.Marker({
        position: {
            lat: 53.480759,
            lng: -2.242631

        },
        icon: "/wp-content/uploads/2017/11/marker.png",
        map: map,
        title: "Hello World!"
    });
        new google.maps.Marker({
        position: {
            lat: 52.486243,
            lng: -1.890401

        },
        icon: "/wp-content/uploads/2017/11/marker.png",
        map: map,
        title: "Hello World!"
    });
        new google.maps.Marker({
        position: {
            lat: 54.978252,
            lng: -1.617780
            
        },
        icon: "/wp-content/uploads/2017/11/marker.png",
        map: map,
        title: "Hello World!"
    });
};
