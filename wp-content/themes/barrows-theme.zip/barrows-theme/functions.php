<?php

//Page Slug Body Class
function add_slug_body_class( $classes ) {
global $post;
if ( isset( $post ) ) {
$classes[] = $post->post_type . '-' . $post->post_name;
}
return $classes;
}
add_filter( 'body_class', 'add_slug_body_class' );

function kryps_enqueue_scripts() {
	wp_enqueue_style( 'parent-style', get_template_directory_uri().'/style.css' );
    wp_enqueue_style( 'font-awesome', get_stylesheet_directory_uri().'/assets/css/font-awesome.min.css' );
    wp_enqueue_style( 'font-awesome', 'https://fonts.googleapis.com/css?family=Poppins:400,700,900' );
    
    wp_enqueue_style( 'slick', get_stylesheet_directory_uri().'/assets/css/slick.css' );
    wp_enqueue_style( 'materialize', get_stylesheet_directory_uri().'/assets/css/materialize.css' );
    wp_enqueue_style( 'slick-theme', get_stylesheet_directory_uri().'/assets/css/slick-theme.css' );

    wp_enqueue_script( 'slick-js', get_stylesheet_directory_uri() . '/assets/js/slick.min.js', array( 'jquery' ),null,true );
    wp_enqueue_script( 'materialize', get_stylesheet_directory_uri() . '/assets/js/materialize.min.js');
    wp_enqueue_script( 'main-js', get_stylesheet_directory_uri() . '/assets/js/barrows_forrester-0.1.0.min.js', array( 'jquery' ),null,true );
    wp_enqueue_script( get_stylesheet_directory_uri() . 'https://maps.googleapis.com/maps/api/js?v=3.exp
        &key=AIzaSyB9nipQ6B_IBb_bQg0BzSkamspph78dul0&callback=initMap', array( 'jquery' ),null,true );
}
add_action( 'wp_enqueue_scripts', 'kryps_enqueue_scripts' );

/* Disable WordPress Admin Bar for all users but admins. */
// show_admin_bar(false);
?>

